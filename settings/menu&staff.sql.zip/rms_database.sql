-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2020 at 04:04 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rms_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL,
  `menu_name` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `menu_description` varchar(200) NOT NULL,
  `menu_price` float NOT NULL,
  `menu_picture` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menu_name`, `category_id`, `menu_description`, `menu_price`, `menu_picture`) VALUES
(101, 'Chicken Chop', 1100, 'A chicken chop is a deboned chicken leg with about 1 in / 2cm of the tail end of the bottom of the drumstick left in.', 9, '../images/MenuManagement/western/chicken_chop.jpg'),
(102, 'Egg Sandwich', 1100, 'A sandwich with some kind of cooked egg filling such as fried eggs, scrambled eggs, sliced boiled eggs and egg salad.', 4.5, '../images/MenuManagement/western/egg_sandwich.jpg'),
(103, 'Fish & Chips', 1100, ' A hot dish consisting of fried fish in batter served with chips.', 10, '../images/MenuManagement/western/fish_&_chips.jpg'),
(104, 'Grill Chicken', 1100, 'a quick meal with tender juicy chicken in a flavorful marinade', 10, '../images/MenuManagement/western/grill_chicken.jpg'),
(105, 'Lamb Chop', 1100, 'A typically bone-in meat chops, cut from the shoulder, loin, sirloin, or rib of the animal.', 12, '../images/MenuManagement/western/lamb_chop.jpg'),
(106, 'Brisket', 1100, 'Meat that rubbing with a spice rub or marinating the meat, and then cooking slowly over indirect heat from charcoal or wood.', 15, '../images/MenuManagement/western/brisket.jpg'),
(107, 'Mac & Cheese', 1100, 'A dish of cooked macaroni pasta and a cheese sauce, most commonly cheddar. It can also incorporate other ingredients, such as breadcrumbs, meat and vegetables.', 8.5, '../images/MenuManagement/western/mac_&_cheese.jpg'),
(108, 'Smoked Burger', 1100, 'A burger consisting of smoked  patties of ground meat, nice aroma spices, and fresh vegetable, placed inside a sliced bun. ', 6.5, '../images/MenuManagement/western/smoked_burger.jpg'),
(109, 'Spaghetti Bolognese', 1100, 'Spaghetti are serve with bolognese sauce that is a meat-based sauce in Italian cuisine', 7.5, '../images/MenuManagement/western/spaghetti_bologne'),
(110, 'Spaghetti Carbonara', 1100, 'Spaghetti that serve with carbonara that is an Italian pasta dish from Rome made with egg, hard cheese, cured pork, and black pepper.', 7.5, '../images/MenuManagement/western/spaghetti_carbona'),
(201, 'Chicken Rice', 1200, 'A dish of poached chicken and seasoned rice, served with chilli sauce and usually with cucumber garnishes.', 6.5, '../images/MenuManagement/oriental/chicken_rice.jpg'),
(202, 'Duck Rice', 1200, 'A dish roasted or braised duck coupled with a mound of rice and doused with soy sauce and a sprinkling of spring onions.', 7, '../images/MenuManagement/oriental/duck_rice.jpg'),
(203, 'Fried Noodle', 1200, 'A perfect way to create a hearty, quick, and healthy one-dish meal.', 4.5, '../images/MenuManagement/oriental/fried_noodle.jpg'),
(204, 'Fried Rice', 1200, ' A dish that was stir-fried in a wok and is usually mixed with other ingredients such as eggs, vegetables, seafood, or meat.', 4.5, '../images/MenuManagement/oriental/fried_rice.jpg'),
(205, 'Nasi Lemak', 1200, 'A Malay cuisine dish consisting of fragrant rice cooked in coconut milk and pandan leaf, commonly found in Malaysia.', 6.5, '../images/MenuManagement/oriental/nasi_lemak.jpg'),
(206, 'Laksa', 1200, 'Spicy noodle soup popular in the Peranakan cuisine of Southeast Asia.', 4.5, '../images/MenuManagement/oriental/laksa.jpg'),
(207, 'Beef Noodle Soup', 1200, 'A noodle soup made of stewed or red braised beef, beef broth, vegetables and Chinese noodles', 5.5, '../images/MenuManagement/oriental/beef_noodle_soup'),
(208, 'Congee', 1200, 'A type of rice porridge serve with various of topping such as ginger, garlic, green onions, cilantro, sesame seeds, soy sauce, Sriracha, and a few drops of toasted sesame oil', 4.5, '../images/MenuManagement/oriental/congee.jpg'),
(209, 'Ma Po Tofu', 1200, 'A popular Chinese dish from Sichuan province. It consists of tofu set in a spicy sauce, typically a thin, oily, and bright red suspension, based on douban and douchi, along with minced meat.', 7.5, '../images/MenuManagement/oriental/mapo_tofu.jpg'),
(210, 'Pancit Molo', 1200, 'A type of soup using wonton wrappers which originated from Molo district in Iloilo City. It consists of a mixture of ground beef wrapped in molo or wonton wrapper, shredded chicken meat.', 6.5, '../images/MenuManagement/oriental/pancit_molo.jpg'),
(301, 'Gaeng Kiew Wan Gai', 1300, 'One of the most famous and sought after Thai dishes is Thai green curry that have unforgettable blend of delights.', 15, '../images/MenuManagement/thai/gaeng_kiew_wan_gai.j'),
(302, 'Guay Jeb', 1300, 'A celebrated rolls of wide rice noodles that look like one-inch cigars to a thick light brown and fatty broth', 6.5, '../images/MenuManagement/thai/guay_jab.jpg'),
(303, 'Kai Jiew Moo Saap', 1300, 'Eggs are beat up with a dash of fish sauce and soy sauce and then minced pork is added.', 5, '../images/MenuManagement/thai/kai_jiew_moo_saap.jp'),
(304, 'Kao Moo Dang', 1300, 'Pork boiled for hours in a sweet soy sauce base with hints of cinnamon and anise are the signature characteristics of kao ka moo.', 6.5, '../images/MenuManagement/thai/kao_moo_dang.jpg'),
(305, 'Kao Niao Ma Muang', 1300, 'A small bed of super glutinous rice is placed below some slices of super sweet, non stringy, ripened mango.', 4, '../images/MenuManagement/thai/kao_niao_ma_muang.jp'),
(306, 'Pad Kra Pao', 1300, 'Phat kaphrao consists of pork and seafood stir fried with Thai holy basil and garlic. It is served with rice and topped up with fried eggs', 4.5, '../images/MenuManagement/thai/pad_kra_pao.jpg'),
(307, 'Pad Thai', 1300, 'Pad Thai is a Thai noodle stir fry with a sweet-savoury-sour sauce scattered with crushed peanuts.', 4.5, '../images/MenuManagement/thai/pad_thai.jpg'),
(308, 'Plah Neung Manow', 1300, 'A whole steamed snapper swimming in a tangy lime juice sauce is served in a metal fish shaped pan with a candle lit underneath to keep it steaming.', 10, '../images/MenuManagement/thai/pla_neung_manao.jpg'),
(309, 'Tom Yum Gung', 1300, 'Thai masterpiece soup is teeming with shrimp, mushrooms, tomatoes, lemongrass, galangal and kaffir lime leaves.', 15, '../images/MenuManagement/thai/tom_yum_gung.jpg'),
(310, 'Yam Khor Moo Yang', 1300, 'This prized meat salad consists of dripping and tender pork cutlets, grilled and sliced then mixed with lemon juice, parsley, sweet onions and a copious amount of fiery chilies.', 8, '../images/MenuManagement/thai/yam_khor_moo_yang.jp'),
(401, 'Latte (Hot)', 1400, 'A cup of Hot Latte made from fresh grind coffee bean', 3.5, '../images/MenuManagement/drink/caffe_latte.jpg'),
(402, 'Coca-Cola', 1400, 'a carbonated soft drink', 2, '../images/MenuManagement/drink/coca-cola.jpg'),
(403, 'Apple Juice', 1400, 'A fruit juice made by the maceration and pressing of few fresh apple.', 2, '../images/MenuManagement/drink/apple_juice.jpg'),
(404, 'coconut', 1400, 'Coconut water, less commonly known as coconut juice, is the clear liquid inside coconuts.', 4.5, '../images/MenuManagement/drink/coconut.jpg'),
(405, 'Cucumber Water', 1400, 'Dip slices of cucumber in icy cold water and refrigerate it for few hours.', 1.5, '../images/MenuManagement/drink/cucumber.jpg'),
(406, 'Ice Kacang', 1400, 'It contain a large serving of attap chee (palm seed), red beans, sweet corn, grass jelly, roasted peanuts and cubes of agar agar as common ingredients. ', 3.5, '../images/MenuManagement/drink/ice_kacang.jpg'),
(407, 'Milo Dinosaur', 1400, 'Composed of a cup of iced Milo (a chocolate malt beverage) with undissolved Milo powder added on top of it.', 4, '../images/MenuManagement/drink/milo_dinosaur.jpg'),
(408, 'Orange Juice', 1400, 'Orange juice is a liquid extract of the orange tree fruit, produced by squeezing or reaming oranges. ', 3, '../images/MenuManagement/drink/orange_juice.jpg'),
(409, 'Pineapple Juice', 1400, 'Pineapple juice is a liquid made from pressing the natural liquid from the pulp of the pineapple tropical plant. ', 2.5, '../images/MenuManagement/drink/pineapple_juice.jpg'),
(410, 'Watermelon Juice', 1400, 'Refreshing and cool watermelon juice.', 2.5, '../images/MenuManagement/drink/watermelon_juice.jp'),
(501, 'Fried Chicken Skin', 1500, 'Pieces of animal fat and skin that have been fried until crispy and seasoned with salt and other seasonings.', 3.5, '../images/MenuManagement/snack/chicken_skin.jpg'),
(502, 'Tortilla Chips', 1500, 'Made from corn tortillas, which are cut into triangles and then fried—or baked.', 5, '../images/MenuManagement/snack/tortilla_chips.jpg'),
(503, 'Cheesy Wedges', 1500, 'Potato wedges with cheese, accompanied by sweet chilli sauce and sour cream.', 4.5, '../images/MenuManagement/snack/cheesy_wedges.png'),
(504, 'Garlic Bread', 1500, '', 3, '../images/MenuManagement/snack/garlic_bread.jpeg'),
(505, 'Cheese Nugget', 1500, 'A delicious and creamy nuggets that has cheese is melted inside them. ', 5, '../images/MenuManagement/snack/cheese_nugget.jpg'),
(506, 'French Fries', 1500, 'French fries are served hot, either soft or crispy, and are generally eaten as part of lunch or dinner or by themselves as a snack,', 4.5, '../images/MenuManagement/snack/french_frice.jpg'),
(507, 'Fried Chicken Wing', 1500, 'These fried chicken wings are marinated in buttermilk, then coated in seasoned flour and deep fried to golden brown perfection.', 5.5, '../images/MenuManagement/snack/fried_chicken_wing.'),
(508, 'Fried Toufu', 1500, 'Upon frying, the white smooth beancurd is transformed into golden, spongy goodness infused with intense salt and pepper flavours.', 4.5, '../images/MenuManagement/snack/fried_toufu.jpg'),
(509, 'Green Salad', 1500, 'A salad is a dish consisting of pieces of food in a mixture, use a base of leafy greens such as lettuce, arugula/rocket, kale or spinach', 5, '../images/MenuManagement/snack/green_salad.jpg'),
(510, 'Ratatouille', 1500, 'Stewed vegetable dish that have plenty of ingredients include tomato, garlic, onion, courgette, aubergine, capsicum, and some combination of leafy green herbs', 6.5, '../images/MenuManagement/snack/ratatouille.jpg'),
(601, 'Amaretto Brulee', 1600, 'A dessert consisting of a rich custard base topped with a texturally contrasting layer of hardened caramelized sugar.', 5, '../images/MenuManagement/dessert/amaretto_brulee.j'),
(602, 'Brazo Gitano', 1600, 'A Swiss roll, roll cake, cream roll, or Swiss log is a type of rolled sponge cake filled with whipped cream or icing. ', 6, '../images/MenuManagement/dessert/brazo_gitano.jpg'),
(603, 'Caramel Apple Strudel', 1600, 'Apple caramel strudel consists of an oblong strudel pastry jacket with an apple and sweet caramel filling inside.', 6, '../images/MenuManagement/dessert/caramel_apple_str'),
(604, 'Fried Ice-cream', 1600, 'Fried ice cream is a dessert made from a breaded scoop of ice cream that is quickly deep-fried, creating a warm, crispy shell around the still-cold ice cream. ', 4.5, '../images/MenuManagement/dessert/fried_ice_cream.j'),
(605, 'Fruit Tart', 1600, 'Creamy custard filling surrounded by a crisp sweet pastry shell and lots of beautiful fruits.', 5, '../images/MenuManagement/dessert/fruit_tart.jpg'),
(606, 'Macaron', 1600, 'A macaron or French macaroon is a sweet meringue-based confection made with egg white, icing sugar, granulated sugar, almond meal, and food colouring.', 8, '../images/MenuManagement/dessert/macaron.jpg'),
(607, 'Molten Chocolate Cake', 1600, 'Molten chocolate cake is a popular dessert that combines the elements of a chocolate cake and a soufflé. Its name derives from the dessert\'s liquid chocolate center.', 6.5, '../images/MenuManagement/dessert/molten_chocolate_'),
(608, 'Mille-feuille', 1600, 'a mille-feuille is made up of three layers of puff pastry , alternating with two layers of pastry cream.', 6.5, '../images/MenuManagement/dessert/mille_feuille.jpg'),
(609, 'Oreo Cheese Cake', 1600, 'Oreo Cheesecake is thick, creamy and filled with cookies and cream! It’s baked in an Oreo crust and topped with white chocolate ganache and homemade whipped cream', 6, '../images/MenuManagement/dessert/oreo_cheese_cake.'),
(610, 'Soufflé', 1600, 'A soufflé is a baked dish with a flavorful base mixed with beaten egg whites. When baked, air bubbles in the egg whites expand, puffing the soufflé up over the top of the dish.', 8, '../images/MenuManagement/dessert/soufflé.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `menu_category`
--

CREATE TABLE `menu_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu_category`
--

INSERT INTO `menu_category` (`category_id`, `category_name`) VALUES
(1100, 'Western'),
(1200, 'Oriental'),
(1300, 'Thai'),
(1400, 'Drinks'),
(1500, 'Snacks'),
(1600, 'Dessert');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `menu_category`
--
ALTER TABLE `menu_category`
  ADD PRIMARY KEY (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=611;

--
-- AUTO_INCREMENT for table `menu_category`
--
ALTER TABLE `menu_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1602;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `menu_category` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
